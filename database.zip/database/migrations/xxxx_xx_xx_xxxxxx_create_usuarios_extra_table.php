public function up()
{
    Schema::create('usuarios_extra', function (Blueprint $table) {
        $table->id();
        $table->string('telefono');
        $table->string('direccion');
        $table->timestamps();
    });
}

public function down()
{
    Schema::dropIfExists('usuarios_extra');
}
