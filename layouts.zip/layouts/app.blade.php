<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'Mi Aplicación')</title>
    <!-- Aquí puedes enlazar CSS, scripts, meta tags, etc. -->
</head>
<body>
    <header>
        <!-- Barra de navegación, logo, menú, etc. -->
        <nav>
            <a href="/">Inicio</a> |
            <a href="/about">Acerca</a>
            <!-- ... -->
        </nav>
    </header>

    <main>
        @yield('content')
    </main>

    <footer>
        <!-- Pie de página -->
        <p>© 2025 Mi Aplicación</p>
    </footer>
</body>
</html>
